const express = require('express')
const app = express();

const path = require('path')

app.use(express.static(path.join(__dirname,'public')))

const defaultRoute = require('./routes/default')
const userRoute = require('./routes/user')
const errorRoute = require('./routes/error');

app.use(defaultRoute)
app.use(userRoute)
app.use(errorRoute)

app.listen(4200)
