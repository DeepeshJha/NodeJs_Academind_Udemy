const express = require('express')
const app = express()

const bodyParser = require('body-parser')
app.use(bodyParser.urlencoded({extended: false}))

const path = require('path')
app.use(express.static(path.join(__dirname,'public')))

app.set('view engine', 'pug')
app.set('views','views')

const addUserRoute = require('./routes/add-user')
const userRoute =  require('./routes/users')

app.use(addUserRoute.router)
app.use(userRoute)

app.listen(4200)


