const express = require('express')
const router = express.Router()

const adminData = require('./add-user')
router.get('/', (req, res, next) => {
    res.render('users',{pageTitle: 'Users', users: adminData.users, path: '/users'})
})

module.exports = router;